import javax.swing.JFrame;

public class clientTest {
	public static void main(String[] args) {
		TCPClient charlie;
		charlie = new TCPClient("192.168.1.4");
		charlie.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		charlie.startRunning();
	}
}