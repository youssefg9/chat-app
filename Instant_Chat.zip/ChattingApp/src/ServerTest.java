

import javax.swing.JFrame;

public class ServerTest {
	public static void main(String[] args) {
		TCPServer me = new TCPServer();
		me.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		me.startRunning();
	}
}
