
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class TCPServer extends JFrame {
	
	private JTextField userText;
	private JTextArea chatWindow;
	private ObjectOutputStream output;
	private ObjectInputStream input;
	private ServerSocket server;
	private Socket connectionSocket;
	
	//constructor
	public TCPServer(){
		super("JOSEF Instant Messenger");
		userText = new JTextField();
		
		//if the user is not connected no edit can be done
		userText.setEditable(false);
		userText.addActionListener(
			new ActionListener(){
				public void actionPerformed(ActionEvent event){
					try {
						sendMessage(event.getActionCommand());
					} catch (IOException e) {
						e.printStackTrace();
					}
					userText.setText("");
				}
			}
		);
		add(userText, BorderLayout.NORTH);
		chatWindow = new JTextArea();
		add(new JScrollPane(chatWindow));
		setSize(500, 500); //Sets the window size
		setVisible(true);
	}
	
	public void startRunning(){
		try{
			server = new ServerSocket(4440, 100); //6789 is a dummy port for testing, this can be changed. The 100 is the maximum people waiting to connect.
			//we need a continous runningconnection using this loop
			while(true){
				try{
					//Trying to connect and have conversation , so we wait...
					waitForConnection();
					//setup the input and output streams.
					setupStreams();
					// the code that happens during actual chat
					whileChatting();
				}catch(EOFException e){
					showMessage("\n Server ended the connection! ");
				} finally{
					//we need to close the application after closing the server
					closeWindow();
				}
			}
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	//wait for connection, then display connection information 
	private void waitForConnection() throws IOException{
		showMessage(" Waiting for someone to connect... \n");
		connectionSocket = server.accept();   // this variable is only initialised with data once a successful connection happen
		//shows data of the client
		showMessage(" Now connected to " + connectionSocket.getInetAddress().getHostName());
	}
	
	//send and recieve data
	private void setupStreams() throws IOException{
		output = new ObjectOutputStream(connectionSocket.getOutputStream());
		output.flush();  //cleans the buffered data for you!!
		
		input = new ObjectInputStream(connectionSocket.getInputStream()); // we dont need to flush the input's data ,its his duty 
		showMessage("\n Streams are now setup.. \n");
		
	}
	
	//during the chatting session what happens in the GUI
	private void whileChatting() throws  IOException{
		String m = "you are now connected!!";
		showMessage("\n" + m);
		//once the user is connected he's able to type
		abilityToType(true);
		do{
			try{
				m = (String) input.readObject(); // its better than readline as u dont know if the user is always sending strings
				showMessage("\n" + m);
			}catch(ClassNotFoundException e){
				showMessage("The user has sent an unknown object!");
			}
		}
		while(!(m.equals("CLIENT - END")));
	}
	
	//closes all streams when user done chatting
	private void closeWindow() {
		showMessage("\n closing connections..... \n");
		abilityToType(false);
		try{
			//closing stream to user
			output.close();
			//closing stream from user
			input.close();
			//closing the whole socketConnection
			connectionSocket.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	//send messages in realtime inside the model
	private void sendMessage(String message) throws IOException{
		try{
			output.writeObject("SERVER - "+message);  //better than writeByte as we dont know what is being sent
			output.flush();
			//show message on server screen
			showMessage("\nServer - " +message);
		}catch(IOException e){
			chatWindow.append("\n Cannot send this message ,please try again!");
		}
	}
	
	//update chatWindow
		private void showMessage(final String text){
			// we need to update a small part of the GUI without the user feeling a change in any other part 
			SwingUtilities.invokeLater(
				new Runnable(){
					public void run(){
						chatWindow.append(text);
					}
				}
			);
		}
		// promts access to typing into the window
		private void abilityToType(boolean b){
			SwingUtilities.invokeLater(
					new Runnable(){
						public void run(){
							userText.setEditable(b);
						}
					}
				);
		}
	
	
}










